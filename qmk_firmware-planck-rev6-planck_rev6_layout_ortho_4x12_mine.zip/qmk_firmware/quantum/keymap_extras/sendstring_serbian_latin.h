/* Copyright 2020
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// Sendstring lookup tables for Serbian (Latin) layouts

#pragma once

#include "keymap_serbian_latin.h"
#include "quantum.h"

// clang-format off

const uint8_t ascii_to_shift_lut[16] PROGMEM = {
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),

    KCLUT_ENTRY(0, 1, 1, 1, 1, 1, 1, 0),
    KCLUT_ENTRY(1, 1, 1, 0, 0, 0, 0, 1),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 1, 1, 0, 1, 1, 1),
    KCLUT_ENTRY(0, 1, 1, 1, 1, 1, 1, 1),
    KCLUT_ENTRY(1, 1, 1, 1, 1, 1, 1, 1),
    KCLUT_ENTRY(1, 1, 1, 1, 1, 1, 1, 1),
    KCLUT_ENTRY(1, 1, 1, 0, 0, 0, 0, 1),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0)
};

const uint8_t ascii_to_altgr_lut[16] PROGMEM = {
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),

    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(1, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 1, 1, 1, 1, 0),
    KCLUT_ENTRY(1, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 1, 1, 1, 1, 0)
};

const uint8_t ascii_to_keycode_lut[128] PROGMEM = {
    // NUL   SOH      STX      ETX      EOT      ENQ      ACK      BEL
    XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX,
    // BS    TAB      LF       VT       FF       CR       SO       SI
    KC_BSPC, KC_TAB,  KC_ENT,  XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX,
    // DLE   DC1      DC2      DC3      DC4      NAK      SYN      ETB
    XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX,
    // CAN   EM       SUB      ESC      FS       GS       RS       US
    XXXXXXX, XXXXXXX, XXXXXXX, KC_ESC,  XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX,

    //       !        "        #        $        %        &        '
    KC_SPC,  RS_1,    RS_2,    RS_3,    RS_4,    RS_5,    RS_6,    RS_QUOT,
    // (     )        *        +        ,        -        .        /
    RS_8,    RS_9,    RS_PLUS, RS_PLUS, RS_COMM, RS_MINS, RS_DOT,  RS_7,
    // 0     1        2        3        4        5        6        7
    RS_0,    RS_1,    RS_2,    RS_3,    RS_4,    RS_5,    RS_6,    RS_7,
    // 8     9        :        ;        <        =        >        ?
    RS_8,    RS_9,    RS_DOT,  RS_COMM, RS_LABK, RS_0,    RS_LABK, RS_QUOT,
    // @     A        B        C        D        E        F        G
    RS_V,    RS_A,    RS_B,    RS_C,    RS_D,    RS_E,    RS_F,    RS_G,
    // H     I        J        K        L        M        N        O
    RS_H,    RS_I,    RS_J,    RS_K,    RS_L,    RS_M,    RS_N,    RS_O,
    // P     Q        R        S        T        U        V        W
    RS_P,    RS_Q,    RS_R,    RS_S,    RS_T,    RS_U,    RS_V,    RS_W,
    // X     Y        Z        [        \        ]        ^        _
    RS_X,    RS_Y,    RS_Z,    RS_F,    RS_Q,    RS_G,    RS_3,    RS_MINS,
    // `     a        b        c        d        e        f        g
    RS_7,    RS_A,    RS_B,    RS_C,    RS_D,    RS_E,    RS_F,    RS_G,
    // h     i        j        k        l        m        n        o
    RS_H,    RS_I,    RS_J,    RS_K,    RS_L,    RS_M,    RS_N,    RS_O,
    // p     q        r        s        t        u        v        w
    RS_P,    RS_Q,    RS_R,    RS_S,    RS_T,    RS_U,    RS_V,    RS_W,
    // x     y        z        {        |        }        ~        DEL
    RS_X,    RS_Y,    RS_Z,    RS_B,    RS_W,    RS_N,    RS_1,    KC_DEL
};
